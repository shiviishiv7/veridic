import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AllStationComponent } from './component/all-station/all-station.component';
import { CreatestationComponent } from './component/createstation/createstation.component';
import { DetailstationComponent } from './component/detailstation/detailstation.component';

import { StationdetailComponent } from './component/stationdetail/stationdetail.component';
import { UpdatestationComponent } from './component/updatestation/updatestation.component';
@NgModule({
  declarations: [
    AppComponent,
    
    AllStationComponent,
    
    DetailstationComponent,
    CreatestationComponent,
    UpdatestationComponent,
    StationdetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
