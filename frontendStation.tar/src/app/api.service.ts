import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {  Station, StationListResponse, StationResponse } from './model/station.model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

URL:string = "http://localhost:8080/api/v1/station"
// URL:string = "http://localhost:8080/Station"
  constructor(private http:HttpClient) { }


  createStation(station:Station):Observable<StationResponse>{
    return this.http.post<StationResponse>(this.URL+"/add",{"station":station})
  }

 

  getAllStation():Observable<StationListResponse>{
    return this.http.get<StationListResponse>(this.URL)
  }


  findStationByID(Id:number):Observable<StationResponse>{
    return this.http.get<StationResponse>(this.URL+"/show/"+Id)
  }

  deleteStationByID(Id:number):Observable<StationResponse>{
    return this.http.delete<StationResponse>(this.URL+"/"+Id+"/delete")
  }


  removeStation(accountId:number){
    return this.http.delete(this.URL,{params:{"accountId":accountId}})
  }

  updateStation(Id:number,station:Station):Observable<StationResponse>{
    return this.http.put<StationResponse>(this.URL+Id+"/edit",{"station":station})
  }


}
