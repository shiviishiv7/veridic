
export class Station{
id: number
name: string
image: string
pricing: number
address: string
}

export class StationListResponse{
     data:Array<Station>= new Array();
     statusCode:number;
    message:string
}

export class StationResponse{
    data:Station
    statusCode:number;
   message:string
}