import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllStationComponent } from './all-station.component';

describe('AllStationComponent', () => {
  let component: AllStationComponent;
  let fixture: ComponentFixture<AllStationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllStationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllStationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
