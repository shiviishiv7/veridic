import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { Station } from 'src/app/model/station.model';

@Component({
  selector: 'app-all-station',
  templateUrl: './all-station.component.html',
  styleUrls: ['./all-station.component.scss']
})
export class AllStationComponent implements OnInit {

  stationList:Array<Station> = new Array()


  constructor(private apiService:ApiService,private router:Router){

  }
  ngOnInit(): void {
  
    this.apiService.getAllStation()
      .subscribe(res=>{
          console.log(res)
        this.stationList = res['data']
      })

  }
  deleteStation(station:Station){
    console.log(station)

    this.apiService.deleteStationByID(station.id)
      .subscribe(data=>{
          alert(data['message'])
          this.stationList = this.stationList.filter(e=>e.id!=station.id)
      })

  }
  update(station:Station){
    // this.router.navigate(['/updateStation', { id:station.id }]);
    this.router.navigate(['/updateStation'], {queryParams:{"id":station.id}})
  

  }
}
