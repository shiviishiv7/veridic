import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { Station } from 'src/app/model/station.model';

@Component({
  selector: 'app-detailstation',
  templateUrl: './detailstation.component.html',
  styleUrls: ['./detailstation.component.scss']
})
export class DetailstationComponent implements OnInit {

station:Station
  
  
  constructor(
    private route: ActivatedRoute,
    private router:Router,
    private apiService: ApiService,
  ) { }

  ngOnInit(): void {
    // this.getProduct();
    let id:string = this.route.snapshot.paramMap.get('id');

    this.apiService.findStationByID(parseInt(id))
      .subscribe(res=>{
          this.station = res['data']
      })
  }

  backToListStation(){
    this.router.navigateByUrl("")
  }

}
