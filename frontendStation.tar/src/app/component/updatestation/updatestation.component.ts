import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { Station } from 'src/app/model/station.model';

@Component({
  selector: 'app-updatestation',
  templateUrl: './updatestation.component.html',
  styleUrls: ['./updatestation.component.scss']
})
export class UpdatestationComponent implements OnInit {

  station:Station = new Station()


  constructor(
    private route: ActivatedRoute,
    private router:Router,
    private apiService: ApiService,
    private routes: ActivatedRoute
  ) { }

  ngOnInit(): void {
    // this.getProduct();
    this.routes.queryParams
    .filter(params => params.order)
    .subscribe(params => {
      console.log(params); // { order: "popular" }

      this.order = params.order;

      console.log(this.order); // popular
    this.apiService.findStationByID(parseInt(id))
      .subscribe(res=>{
          this.station = res['data']
      })
  }

  updateStation(){
    this.apiService.updateStation(this.station.id,this.station)
      .subscribe(res=>{
          alert(res['message'])
          this.router.navigateByUrl("")
        })
  }

}
