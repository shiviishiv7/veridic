import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stationdetail',
  templateUrl: './stationdetail.component.html',
  styleUrls: ['./stationdetail.component.scss']
})
export class StationdetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
