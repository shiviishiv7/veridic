import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { Station } from 'src/app/model/station.model';

@Component({
  selector: 'app-createstation',
  templateUrl: './createstation.component.html',
  styleUrls: ['./createstation.component.scss']
})
export class CreatestationComponent implements OnInit {

  station:Station = new Station()


  constructor(
    private route: ActivatedRoute,
    private router:Router,
    private apiService: ApiService,
  ) { }

  ngOnInit(): void {
   
  }

  submit(){
    this.apiService.createStation(this.station)
      .subscribe(res=>{
          alert(res['message'])
          this.router.navigateByUrl("")
        })
  }
}
