import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AllStationComponent } from './component/all-station/all-station.component';
import { CreatestationComponent } from './component/createstation/createstation.component';
import { DetailstationComponent } from './component/detailstation/detailstation.component';
import { UpdatestationComponent } from './component/updatestation/updatestation.component';

const routes: Routes = [
  {path:'',component:AllStationComponent,pathMatch:'full'},
  {path:'allStation',component:AllStationComponent,pathMatch:'full'},
  {path:'createStation',component:CreatestationComponent,pathMatch:'full'},
  {path:'updateStation',component:UpdatestationComponent,pathMatch:'full'},
  {path:'detailStation',component:DetailstationComponent,pathMatch:'full'},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
